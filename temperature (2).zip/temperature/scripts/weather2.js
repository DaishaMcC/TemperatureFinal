
function convertTemperatureRange(){
    var option= prompt("Enter the1 option: 1) Fahrenheit, 2) Celsius");
    var temperature= Number(prompt("Enter temoperature here"));
    for(let i=0; i<=100; i++){
        console.log("Loop line "  + i)
    }
    var result = document.getElementById("weather");
    document.write(`<p></p>`)


        
        if(option == 1){
            var celsius=(temperature-32)* 5/9;
            console.log(celsius); // math operation
            result.innerHTML += celsius +=
            `<p>TempC: ${celsius}</p>`
        };
        
        if(option == 2){
            var fahrenheit=(temperature*9/5)+ 32;
            console.log(fahrenheit); // math operation
            result.innerHTML += fahrenheit += 
            `<p>TempF: ${fahrenheit}</p>`
    };

}

// promt user to enter start temp an ending temp and scale either c or f
// scale more informaiton
// document write loop somehow
// so many questionss

